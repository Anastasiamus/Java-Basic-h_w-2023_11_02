package People;

import jdk.internal.jmod.JmodFile;

public class Student {
    public String name;
    private int age;
    String faculty;

    public Student(String name, String faculty, int age) {
        this.name = name;
        this.faculty = faculty;
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if ( age > 18);
        this.age = age;
    }

    public Student (Student original){
        this.name = original.name;
        this.faculty = original.faculty;
        this.age = original.age;

    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", faculty='" + faculty + '\'' +
                '}';
    }
}


/*1.6 Добавьте клонирующий конструктор к классу 1. В программе склонируйте созданный ранее объект. Проверьте с помощью ==, что объекты имеют разные ссылки в памяти.
        1.7 У клона измените одно из полей. Проверьте, что то же поле исходного объекта не изменилось.*/




