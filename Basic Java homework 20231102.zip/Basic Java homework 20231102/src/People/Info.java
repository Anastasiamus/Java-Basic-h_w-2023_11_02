package People;

import java.util.jar.Attributes;
public class Info {
    int course;
    Student student;
    String country;

    private static void makeInfoList(){
        Info info = new Info(2,
                    new Student("Oleg","Biology",25),
                "Germany");
    }


    public Info(int course, Student student) {
        this.course = course;
        this.student = student;
    }

    public Info(int course, Student student, String country) {
        this.course = course;
        this.student = student;
        this.country = country;
    }
}




/*1.2 Создайте второй класс в том же пакете, в котором будет создаваться первый класс
        (например, класс Университет для класса Студент или класс Завод для класса автомобиль).
        Внутри класса определите метод, который создаёт объект первого класса и присвойте ему те поля, которые возможно. Какие поля возможно задать?*/